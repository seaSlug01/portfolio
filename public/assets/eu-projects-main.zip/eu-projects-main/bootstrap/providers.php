<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\FilamentCustomJavascriptFiles::class,
    App\Providers\Filament\AdminPanelProvider::class,
];

<?php

namespace App\Livewire\Components;

use Livewire\Component;

class Tabs extends Component
{
    public function render()
    {
        return view('livewire.components.tabs');
    }
}

<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Partner;
use App\Models\Contact;

class PartnerContactSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $partners = Partner::factory()
            ->count(5) // Create 5 partners
            ->create();

        // Step 2: Create Contacts and Link Them to Partners
        $partners->each(function ($partner) {
            // Create 3 contacts per partner
            $contacts = Contact::factory()
                ->count(3) // Adjust the count as needed
                ->create();

            // Link each contact to the partner with a pivot record
            foreach ($contacts as $index => $contact) {
                $partner->contacts()->attach($contact->id, [
                    'sort' => $index + 1, // Example: Set the sort order (1, 2, 3)
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);
            }
        });
    }
}

<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Category;

class CategorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $categories = [
            [
                'name' => 'Erasmus+',
                'description' => 'European Union program for education, training, youth, and sport, promoting mobility and cross-border cooperation.'
            ],
            [
                'name' => 'Horizon Europe',
                'description' => 'EU’s key funding program for research and innovation tackling climate change and supporting sustainable growth.'
            ],
            [
                'name' => 'Creative Europe',
                'description' => 'A program supporting Europe’s cultural and creative sectors, promoting artistic innovation and heritage.'
            ],
            [
                'name' => 'European Solidarity Corps',
                'description' => 'Program for young people to engage in solidarity projects across Europe, fostering community building and inclusivity.'
            ],
            [
                'name' => 'LIFE Program',
                'description' => 'EU’s funding instrument for environmental and climate action projects, encouraging sustainable practices.'
            ],
            [
                'name' => 'European Regional Development Fund',
                'description' => 'Supports regional economic development, aiming to reduce disparities and promote cohesion across Europe.'
            ],
            [
                'name' => 'Interreg',
                'description' => 'Program focused on fostering cross-border, transnational, and interregional cooperation in the EU.'
            ],
            [
                'name' => 'Asylum, Migration and Integration Fund',
                'description' => 'Program supporting EU member states in managing migration and fostering migrant integration.'
            ],
            [
                'name' => 'European Agricultural Fund for Rural Development',
                'description' => 'Supports projects that improve rural areas, promote agricultural sustainability, and encourage rural development.'
            ],
            [
                'name' => 'CEF (Connecting Europe Facility)',
                'description' => 'Program financing infrastructure projects in transport, energy, and digital services across Europe.'
            ],
        ];

        Category::insert($categories);
    }
}

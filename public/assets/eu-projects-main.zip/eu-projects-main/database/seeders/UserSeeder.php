<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\User;
use Illuminate\Support\Str;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $users =  [
            [
                'name' => 'admin',
                'email' => 'admin@admin.com',
                'email_verified_at' => now(),
                'password' => bcrypt('password'), 
                'remember_token' => Str::random(10),
                'isAdmin' => 1,
                'organization' => 'Elite Services',
                'telephone' => '2101234567',
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'name' => 'kwstas',
                'email' => 'deekwstaz@gmail.com',
                'email_verified_at' => now(),
                'password' => bcrypt('password'),
                'remember_token' => Str::random(10),
                'isAdmin' => 1,
                'organization' => 'Innovation Corp.',
                'telephone' => '6941234567', 
                'created_at' => now(),
                'updated_at' => now(),
            ]
            ];


        User::insert($users);
        User::factory(5)->create();
    }
}

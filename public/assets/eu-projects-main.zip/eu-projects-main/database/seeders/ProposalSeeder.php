<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Proposal;
use \App\Models\Category;
use Illuminate\Support\Facades\DB;

class ProposalSeeder extends Seeder
{
    public function run()
    {
        // Array of proposals to be inserted simultaneously
        $proposals = [
            [
                'title' => 'Erasmus+ Mobility for Higher Education Students',
                'submission_date' => '2024-01-15',
                'description' => 'This Erasmus+ project offers opportunities for students from European universities to gain international experience by studying or doing internships abroad.',
                
                'created_at' => now(),
                'updated_at' => now(),
                'coordinator_id' => 1,
                'approval_status' => 'approved',
                'budget' => 50000,
                'author_id' => 2,
            ],
            [
                'title' => 'Horizon Europe: Green Energy Transition',
                'submission_date' => '2024-02-10',
                'description' => 'This Horizon Europe project focuses on advancing clean energy technologies and sustainable practices to address climate change in the European Union.',
                
                'created_at' => now(),
                'updated_at' => now(),
                'coordinator_id' => 2,
                'approval_status' => 'under_consideration',
                'budget' => 120000,
                'author_id' => 2,
            ],
            [
                'title' => 'European Social Fund: Employment and Skills Development',
                'submission_date' => '2024-03-05',
                'description' => 'This European Social Fund proposal aims to support workforce development through targeted skills training and job placement programs in underserved regions.',
                
                'created_at' => now(),
                'updated_at' => now(),
                'coordinator_id' => 3,
                'approval_status' => 'not_approved',
                'budget' => 75000,
                'author_id' => 2,
            ],
            [
                'title' => 'Erasmus+ Youth Exchange and Inclusion',
                'submission_date' => '2024-04-22',
                'description' => 'Aimed at fostering inclusion and intercultural dialogue, this project will offer youth exchanges and training activities to encourage social participation across European borders.',
                
                'created_at' => now(),
                'updated_at' => now(),
                'coordinator_id' => 4,
                'approval_status' => 'approved',
                'budget' => 40000,
                'author_id' => 2,
            ],
            [
                'title' => 'Horizon Europe: Digital Innovation and Research',
                'submission_date' => '2024-05-14',
                'description' => 'This proposal focuses on accelerating digital innovation and research in Europe by supporting the development of cutting-edge technologies in AI, cybersecurity, and blockchain.',
                'created_at' => now(),
                'updated_at' => now(),
                'coordinator_id' => 5,
                'approval_status' => 'under_consideration',
                'budget' => 150000,
                'author_id' => 2,
            ],
            [
                'title' => 'Creative Europe: Cultural Exchange Programs',
                'submission_date' => '2024-06-01',
                'description' => 'Creative Europe will support cross-border cultural exchanges and the development of the creative industries by facilitating international collaborations among artists and organizations.',
                'created_at' => now(),
                'updated_at' => now(),
                'coordinator_id' => 5,
                'approval_status' => 'approved',
                'budget' => 60000,
                'author_id' => 2,
            ],
            [
                'title' => 'Erasmus+ Vocational Education and Training',
                'submission_date' => '2024-07-18',
                'description' => 'This project will improve the quality of vocational education and training (VET) across Europe, promoting knowledge exchange and best practices among European VET institutions.',
                'created_at' => now(),
                'updated_at' => now(),
                'coordinator_id' => 3,
                'approval_status' => 'not_approved',
                'budget' => 30000,
                'author_id' => 2,
            ],
            [
                'title' => 'Horizon Europe: Smart Cities and Urban Mobility',
                'submission_date' => '2024-08-10',
                'description' => 'This Horizon Europe project will support the development of smart cities by promoting sustainable urban mobility solutions and improving energy efficiency in urban planning.',
                'created_at' => now(),
                'updated_at' => now(),
                'coordinator_id' => 4,
                'approval_status' => 'approved',
                'budget' => 90000,
                'author_id' => 2,
            ],
            [
                'title' => 'European Regional Development Fund: Infrastructure Development',
                'submission_date' => '2024-09-23',
                'description' => 'This proposal focuses on funding infrastructure projects in economically disadvantaged regions of the EU, with a focus on sustainable development and job creation.',
                'created_at' => now(),
                'updated_at' => now(),
                'coordinator_id' => 4,
                'approval_status' => 'under_consideration',
                'budget' => 100000,
                'author_id' => 2,
            ],
            [
                'title' => 'Erasmus+ Adult Education and Lifelong Learning',
                'submission_date' => '2024-10-05',
                'description' => 'This Erasmus+ proposal aims to enhance adult education and lifelong learning programs across Europe, fostering skills development and personal growth for adult learners.',
                'created_at' => now(),
                'updated_at' => now(),
                'coordinator_id' => 5,
                'approval_status' => 'not_approved',
                'budget' => 50000,
                'author_id' => 2,
            ],
            [
                'title' => 'Empowerment Through Digital Leadership',
                'submission_date' => '2024-02-25',
                'description' => 'A project aimed at empowering young individuals by equipping them with the skills and leadership qualities necessary to create digital solutions for their communities.',
                'created_at' => now(),
                'updated_at' => now(),
                'coordinator_id' => 3,
                'approval_status' => 'under_consideration',
                'budget' => 40000,
                'author_id' => 2,
            ],
            [
                'title' => 'Reviving the Earth: Digital Tools for Conservation',
                'submission_date' => '2024-03-05',
                'description' => 'A project focused on using advanced digital solutions to monitor ecosystems, reduce pollution, and support nature preservation in threatened regions.',
                'created_at' => now(),
                'updated_at' => now(),
                'coordinator_id' => 4,
                'approval_status' => 'approved',
                'budget' => 90000,
                'author_id' => 2,
            ],
            [
                'title' => 'The Green Generation: Youth in Action',
                'submission_date' => '2024-03-15',
                'description' => 'A project designed to encourage youth to take a leading role in environmental activism, by providing them with the tools and platforms to create lasting change.',
                'created_at' => now(),
                'updated_at' => now(),
                'coordinator_id' => 5,
                'approval_status' => 'approved',
                'budget' => 75000,
                'author_id' => 2,
            ],
            [
                'title' => 'The Smart Earth Initiative',
                'submission_date' => '2024-04-01',
                'description' => 'Focusing on using smart technology to improve sustainable practices in agriculture, renewable energy, and waste management to promote environmental well-being.',
                'created_at' => now(),
                'updated_at' => now(),
                'coordinator_id' => 2,
                'approval_status' => 'under_consideration',
                'budget' => 120000,
                'author_id' => 2,
            ],
            [
                'title' => 'Young Innovators: Solutions for a Greener Tomorrow',
                'submission_date' => '2024-04-10',
                'description' => 'A project designed to provide young people with the opportunity to collaborate on green innovations that can improve the sustainability of cities and rural areas.',
                'created_at' => now(),
                'updated_at' => now(),
                'coordinator_id' => 1,
                'approval_status' => 'approved',
                'budget' => 85000,
                'author_id' => 2,
            ],
            [
                'title' => 'Digital Impact: Harnessing Data for Environmental Change',
                'submission_date' => '2024-04-18',
                'description' => 'A project focused on harnessing the power of big data to help create actionable insights for better environmental policy and decision-making.',
                'created_at' => now(),
                'updated_at' => now(),
                'coordinator_id' => 3,
                'approval_status' => 'not_approved',
                'budget' => 65000,
                'author_id' => 2,
            ],
            [
                'title' => 'Bridging Nature and Technology: Creating Sustainable Solutions',
                'submission_date' => '2024-05-02',
                'description' => 'This project aims to bridge the gap between natural resource management and cutting-edge technology, helping communities adapt to climate change through smart tools.',
                'created_at' => now(),
                'updated_at' => now(),
                'coordinator_id' => 2,
                'approval_status' => 'under_consideration',
                'budget' => 95000,
                'author_id' => 2,
            ],
            [
                'title' => 'Redefining Leadership in a Digital Age',
                'submission_date' => '2024-05-12',
                'description' => 'A leadership development project for young individuals, combining online platforms and mentorship to inspire future leaders focused on digital transformation and societal impact.',
                'created_at' => now(),
                'updated_at' => now(),
                'coordinator_id' => 1,
                'approval_status' => 'approved',
                'budget' => 70000,
                'author_id' => 2,
            ],
            [
                'title' => 'Nature Reborn: Using Technology to Heal Our Planet',
                'submission_date' => '2024-06-01',
                'description' => 'A project that combines environmental science with technological innovation to rehabilitate ecosystems and fight deforestation, utilizing drones and AI-powered monitoring.',
                'created_at' => now(),
                'updated_at' => now(),
                'coordinator_id' => 4,
                'approval_status' => 'approved',
                'budget' => 80000,
                'author_id' => 2,
            ],
            [
                'title' => 'Sustainable Cities: Youth-Driven Urban Solutions',
                'submission_date' => '2024-06-15',
                'description' => 'This project empowers youth to develop innovative solutions for making cities more sustainable, including renewable energy projects, waste management, and green urban planning.',
                'created_at' => now(),
                'updated_at' => now(),
                'coordinator_id' => 5,
                'approval_status' => 'approved',
                'budget' => 95000,
                'author_id' => 2,
            ],
        ];

        // Insert all proposals at once
        Proposal::insert($proposals);

        $totalCategories = Category::count();
        $totalProposals = count($proposals);

        foreach ($proposals as $index => $proposal) {
            $proposalId = $index + 1;

            $partnersCount = rand(0, 4);

            for ($i = 0; $i < $partnersCount; $i++) {
                $proposalPartners[] = [
                    'proposal_id' => $proposalId,
                    'partner_id' => rand(1, 5),
                    'order' => $i + 1,
                    'created_at' => now(),
                    'updated_at' => now(),
                ];
            }


            $categoryProposals[] = [
                'category_id' => rand(1, $totalCategories),
                'proposal_id' => rand(1, $totalProposals),
                'created_at' => now(),
                'updated_at' => now(),
            ];
        }

        DB::table('proposal_partner')->insert($proposalPartners);
        DB::table('category_proposal')->insert($categoryProposals);
    }
}

<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Post;
use App\Models\Partner;
use App\Models\Category;
use Illuminate\Support\Str;

class PostSeeder extends Seeder
{
    public function run()
    {
        // Fetch all available partners and categories
        $partners = Partner::all();
        $categories = Category::all();
        $authorIds = [1, 2];

        if ($partners->count() < 5) {
            $this->command->error('You need at least 5 partners to run this seeder.');
            return;
        }

        // Define post data
        $postsData = [
            [
                'title' => 'Erasmus+ Mobility for Higher Education Students',
                'content' => 'This Erasmus+ project offers opportunities for students from European universities to gain international experience by studying or doing internships abroad.',
                'description' => 'Erasmus+ provides students the opportunity to enhance their academic learning, gain cross-cultural experiences, and increase their employability by studying abroad in European countries.',
            ],
            [
                'title' => 'Horizon Europe Research Initiatives for Innovation',
                'content' => 'Horizon Europe is the EU’s largest funding program for research and innovation, aimed at tackling global challenges and fostering economic growth.',
                'description' => 'With a budget exceeding €90 billion, Horizon Europe funds groundbreaking research projects that address pressing issues such as climate change, health, and digital transformation.',
            ],
            [
                'title' => 'Creative Europe: Supporting Cultural and Creative Sectors',
                'content' => 'The Creative Europe program supports Europe’s cultural and creative sectors, helping artists and cultural organizations to reach new audiences and create innovative works.',
                'description' => 'Creative Europe fosters cooperation across borders within the EU, supporting projects in film, music, visual arts, and other creative industries to promote European cultural diversity.',
            ],
            [
                'title' => 'European Solidarity Corps: Volunteering Across Europe',
                'content' => 'The European Solidarity Corps enables young people to participate in solidarity projects in their home country or abroad, fostering community engagement and social inclusion.',
                'description' => 'By volunteering with the European Solidarity Corps, young individuals can gain valuable experience, enhance their skills, and contribute to strengthening communities in Europe.',
            ],
            [
                'title' => 'LIFE Program: Environmental and Climate Action Initiatives',
                'content' => 'The LIFE program is the EU’s funding instrument for the environment and climate action, supporting projects that promote sustainability and fight climate change.',
                'description' => 'With a focus on innovative environmental practices, the LIFE program helps NGOs, businesses, and local authorities develop initiatives that preserve nature and reduce carbon footprints.',
            ],
            [
                'title' => 'Interreg: Boosting Cross-Border Cooperation in Europe',
                'content' => 'Interreg programs encourage regional cooperation across EU borders, facilitating joint projects between neighboring countries to promote economic development and cultural exchange.',
                'description' => 'Through Interreg, local and regional authorities collaborate on initiatives that improve public infrastructure, education systems, and healthcare services in border regions.',
            ],
            [
                'title' => 'Asylum, Migration, and Integration Fund: Promoting Inclusive Societies',
                'content' => 'The Asylum, Migration, and Integration Fund helps EU member states manage migration flows and ensure the integration of migrants into society.',
                'description' => 'The fund provides financial support for initiatives that improve the reception and integration of migrants, ensuring social inclusion, employment, and education opportunities for newcomers.',
            ],
            [
                'title' => 'Connecting Europe Facility: Advancing EU Infrastructure Projects',
                'content' => 'The Connecting Europe Facility (CEF) supports the development of transport, energy, and digital infrastructures to enhance European connectivity and integration.',
                'description' => 'By investing in cross-border infrastructures, CEF helps improve the movement of goods, energy resources, and digital data, contributing to the EU’s competitiveness and sustainability.',
            ],
            [
                'title' => 'European Regional Development Fund: Strengthening EU Regions',
                'content' => 'The European Regional Development Fund (ERDF) supports economic development and cohesion in underdeveloped regions within the EU.',
                'description' => 'The ERDF funds projects that foster regional growth, job creation, and innovation, aiming to reduce disparities and ensure that all regions benefit from Europe’s economic growth.',
            ],
            [
                'title' => 'European Agricultural Fund for Rural Development: Empowering Rural Communities',
                'content' => 'The European Agricultural Fund for Rural Development (EAFRD) supports the development of rural areas through sustainable agricultural practices and local economic development.',
                'description' => 'The fund promotes eco-friendly farming, rural entrepreneurship, and the preservation of rural heritage, ensuring long-term prosperity for rural communities across Europe.',
            ],
        ];

        // Create the posts using the data defined above
        foreach ($postsData as $data) {
            $post = Post::create([
                'title' => $data['title'],
                'content' => $data['content'],
                'description' => $data['description'],
                'category_id' => $categories->random()->id,
                'coordinator_id' => $partners->random()->id,  
                'duration' => $this->generateRandomDuration(),
                'budget' => rand(10000, 500000), 
                'website' => Str::slug($data['title']) . '.com',
                'code' => strtoupper(\Illuminate\Support\Str::random(6)),
                'submission_date' => now(),
                'finished' => rand(0, 1) == 1,
                'author_id' => $authorIds[array_rand($authorIds)],
                'color' => $this->generateRandomColor(),
                'slug' => $this->generateSlug($data['title'])
            ]);

            // Attach 1-3 partners to each post in the post_partner pivot table
            $selectedPartners = $partners->random(rand(1, 3));
            foreach ($selectedPartners as $index => $partner) {
                $post->partners()->attach($partner->id, [
                    'order' => $index + 1,
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);
            }
        }

        $this->command->info('10 posts with real-looking data have been seeded.');
    }

    private function generateSlug($title)
    {
        $slug = Str::slug($title);  // Generate the slug from the title
        return substr($slug, 0, 10);  // Truncate the slug to a maximum of 10 characters
    }

    // Helper method to generate random duration in the format dd/mm/yyyy - dd/mm/yyyy
    private function generateRandomDuration()
    {
        $startDate = \Carbon\Carbon::now()->addDays(rand(1, 30)); // Random start date within 30 days
        $endDate = $startDate->copy()->addDays(rand(1, 10)); // Random end date between 1-10 days after start date

        return $startDate->format('d/m/Y') . ' - ' . $endDate->format('d/m/Y');
    }

    private function generateRandomColor()
    {
        return '#' . strtoupper(dechex(rand(0x000000, 0xFFFFFF)));  // Random hex color code
    }
}


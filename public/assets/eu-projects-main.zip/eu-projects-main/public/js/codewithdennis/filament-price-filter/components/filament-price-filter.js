function t({state:i}){return{state:i,init:function(){}}}export{t as default};
